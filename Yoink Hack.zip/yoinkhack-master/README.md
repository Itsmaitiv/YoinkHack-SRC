## Strong people
darki<br>
neko<br>
praam<br>
69hr<br>
aluminisin<br>
i am become death<br>
mikk<br>
plivid<br>
tbm<br>
b0ba<br>
dacha<br>
svintus<br>
daisy<br>
asdf<br>
and more i might have forgot

#### NOTE: For those suspicious of the discord rpc binaries
Simply replace them with the ones you can download [here](https://github.com/discord/discord-rpc/releases)
 
