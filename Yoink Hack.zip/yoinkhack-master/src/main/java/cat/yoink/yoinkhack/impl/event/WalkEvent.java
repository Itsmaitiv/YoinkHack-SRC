package cat.yoink.yoinkhack.impl.event;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class WalkEvent extends Event
{
}
