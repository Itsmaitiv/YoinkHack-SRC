package cat.yoink.yoinkhack.impl.module.misc;

import cat.yoink.yoinkhack.api.module.Category;
import cat.yoink.yoinkhack.api.module.Module;

public class AntiNarrator extends Module
{
	public AntiNarrator(String name, Category category, String description)
	{
		super(name, category, description);
	}
}

