package cat.yoink.yoinkhack.impl.module.render;

import cat.yoink.yoinkhack.api.module.Category;
import cat.yoink.yoinkhack.api.module.Module;

public class ShulkerViewer extends Module
{
	public ShulkerViewer(String name, Category category, String description)
	{
		super(name, category, description);
	}
}
