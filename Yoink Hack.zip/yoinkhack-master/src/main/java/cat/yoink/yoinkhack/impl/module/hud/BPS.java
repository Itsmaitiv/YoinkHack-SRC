package cat.yoink.yoinkhack.impl.module.hud;

import cat.yoink.yoinkhack.api.module.Category;
import cat.yoink.yoinkhack.api.module.Module;

public class BPS extends Module
{
	public BPS(String name, Category category, String description)
	{
		super(name, category, description);
	}
}
